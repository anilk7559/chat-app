import { createAction } from '../utils';

export const setReadyState = createAction('APP_STATE_SUCCESS');
export const resetAppState = createAction('APP_STATE_RESET');
