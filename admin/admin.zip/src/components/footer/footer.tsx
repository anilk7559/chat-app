function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="main-footer">
      <strong>
        Copyright @
        {year}
      </strong>
    </footer>
  );
}

export default Footer;
