export interface IAppSetting {
  siteName: string,
  beforeHead: string,
  afterBody: string
}
