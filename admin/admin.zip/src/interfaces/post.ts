export interface IPost {
  title: string,
  alias: string,
  content: any,
  ordering: number,
  categoryIds: Array<any>,
  type: string
}
