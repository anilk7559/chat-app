declare namespace NodeJS {
  interface Process {
    browser: boolean;
  }
}

declare module '@fortawesome/free-solid-svg-icons';
declare module 'react-loading-bar';