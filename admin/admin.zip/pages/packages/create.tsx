import React from 'react';
import { Container } from 'reactstrap';
import Router from 'next/router';
import { toast } from 'react-toastify';
import Head from 'next/head';
import { packageService } from '@services/package.service';
import PackageForm from '../../src/components/packages/form';

function PackageCreate() {
  const savePackages = async (data) => {
    try {
      await packageService.create(data);
      toast.success('Package has been created');
      Router.push('/packages/listing');
    } catch (e) {
      const error = await e;
      toast.error(error?.message || 'Create package fail');
    }
  };
  return (
    <>
      <Head>
        <title>Create package</title>
      </Head>
      <h4 className="title-table">Create Package</h4>
      <Container fluid className="content">
        <PackageForm submit={savePackages} />
      </Container>
    </>
  );
}
export default PackageCreate;
