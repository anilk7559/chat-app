import { Container } from 'reactstrap';
import Head from 'next/head';
import { menuService } from '@services/menu.service';
import { toast } from 'react-toastify';
import Router from 'next/router';
import MenuForm from 'src/components/menu/form';

function MenuCreate() {
  const submitMenu = async (data) => {
    try {
      await menuService.create(data);
      toast.success('Menu has been created successfully!');
      Router.push('/settings/menus/listing');
    } catch (e) {
      const err = await e;
      toast.error(err?.message || 'Create menu fail!');
    }
  };
  return (
    <Container fluid className="content">
      <Head>
        <title>Menu create</title>
      </Head>
      <MenuForm submit={submitMenu} />
    </Container>
  );
}
export default MenuCreate;
